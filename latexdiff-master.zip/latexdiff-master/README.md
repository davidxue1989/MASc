latexdiff
=========

Compares two latex files and marks up significant differences between them. Releases on www.ctan.org and mirrors
